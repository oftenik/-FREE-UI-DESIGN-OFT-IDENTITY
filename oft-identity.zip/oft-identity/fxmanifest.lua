fx_version 'cerulean'
game 'gta5'

author 'oftenik'
description 'oftenik identity'
version '1.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/main.js',
    'html/style.css',
    'html/click-sound.mp3'
}

client_script 'client.lua'
