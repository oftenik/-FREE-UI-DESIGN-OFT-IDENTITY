function submitForm() {
    const imie = document.getElementById("imie").value;
    const nazwisko = document.getElementById("nazwisko").value;
    const dataUrodzenia = document.getElementById("data-urodzenia").value;
    const wzrost = parseInt(document.getElementById("wzrost").value);
    const plec = document.getElementById("plec").value;
    const narodowosc = document.getElementById("narodowosc").value;

    if (!imie || !nazwisko || !dataUrodzenia || !wzrost || !plec || !narodowosc) {
        alert("Proszę wypełnić wszystkie pola.");
        return;
    }

    if (wzrost < 120 || wzrost > 210) {
        alert("Wzrost musi być pomiędzy 120 cm a 210 cm.");
        return;
    }

    const birthYear = new Date(dataUrodzenia).getFullYear();
    if (birthYear < 1950 || birthYear > 2025) {
        alert("Data urodzenia musi być pomiędzy 1950 a 2025 rokiem.");
        return;
    }

    const characterData = {
        imie: imie,
        nazwisko: nazwisko,
        dataUrodzenia: dataUrodzenia,
        wzrost: wzrost,
        plec: plec,
        narodowosc: narodowosc
    };

    console.log("Character Data:", characterData);

    const napisElement = document.querySelector('.napis');
    napisElement.innerText = `${imie} ${nazwisko}, ${wzrost} cm, ${plec}, ${narodowosc}`;
    
    const postacElement = document.querySelector('.postac');
    postacElement.style.display = 'none';
    const kreskaElement = document.querySelector('.kreska');
    kreskaElement.style.display = 'none';

    document.getElementById("imie").value = "";
    document.getElementById("nazwisko").value = "";
    document.getElementById("data-urodzenia").value = "";
    document.getElementById("wzrost").value = "";
    document.getElementById("plec").value = "";
    document.getElementById("narodowosc").value = "";

    var audio = document.getElementById('click-sound');
    audio.play();
}


var audio = document.getElementById('click-sound');
audio.addEventListener('canplaythrough', function() {
    console.log('Dźwięk jest gotowy do odtworzenia.');
}, false);
audio.addEventListener('error', function(e) {
    console.log('Wystąpił błąd podczas ładowania dźwięku', e);
}, false);

function capitalizeFirstLetter(element) {
    let value = element.value;
    if (value.length > 0) {
        element.value = value.charAt(0).toUpperCase() + value.slice(1);
    }
}

document.getElementById('imie').addEventListener('input', function() {
    capitalizeFirstLetter(this);
});

document.getElementById('nazwisko').addEventListener('input', function() {
    capitalizeFirstLetter(this);
})


